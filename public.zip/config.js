const url = 'http://localhost:3000';

module.exports = {
    url
};